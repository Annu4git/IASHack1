echo "Please enter the IP Address:- "
read ip
echo "Please enter Username:-"
read uname
echo "Please enter Password:-"
read -s pass
# python model.py
echo "Training of the model done!"
sshpass -p "$pass" scp -r tf_logs "$uname"@"$ip":tf_logs
sshpass -p "$pass" scp data_helpers_client.py "$uname"@"$ip":data_helpers.py
sshpass -p "$pass" scp Dockerfile "$uname"@"$ip":Dockerfile
sshpass -p "$pass" scp restore_model.py "$uname"@"$ip":restore_model.py
sshpass -p "$pass" scp softmax.py  "$uname"@"$ip":softmax.py
sshpass -p "$pass" scp test.sh  "$uname"@"$ip":test.sh
sshpass -p "$pass" scp two_layer_fc.py  "$uname"@"$ip":two_layer_fc.py


echo "File transfered"


# sshpass -p "swiggy" scp test.py "$uname"@"$ip":testing.py
