sudo apt-get install curl
#installation of docker
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable edge"
apt-cache policy docker-ce
sudo apt-get install -y docker-ce


#building the model
sudo docker build -t testing_env .
sudo docker run -i -t testing_env
sudo docker exec -t -i testing_env "execfile('restore_model.py')"

